Upload these files to a GitHub repository, then deploy on Render as a Python Web Service.

Build Command:
pip install -r requirements.txt

Start Command:
bash start.sh
